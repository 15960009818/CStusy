//
// Created by 1 on 2024/4/23.
//

#ifndef CSTUDY09_CREGWIN_H
#define CSTUDY09_CREGWIN_H
void regWin();
#endif //CSTUDY09_CREGWIN_H
