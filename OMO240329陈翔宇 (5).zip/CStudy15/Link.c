#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct Menu {
    int id;
    char name[100];
    float price;
    char info[100];
    struct Menu *next;
} MENU_T;

int ID = 1001;
// ��ʼ������
MENU_T* menuList_init() {
    return NULL;
}
/**
 * ���Ӳ�Ʒ������ĩβ
 * @param head  ͷ�ڵ�
 * @param menu  �˵���Ϣ
 * @updatetime 2024.5.7
 * @author xiangjun
 */
// ���Ӳ�Ʒ������ĩβ
void menuList_add(MENU_T **head, MENU_T *menu) {
    menu->id = ID++;

    if (*head == NULL) {
        *head = menu;
    } else {
        MENU_T *current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = menu;
    }
}
/**
 * ͳ�ƽڵ����
 * @param head ͷ�ڵ�
 * @return count �ڵ�����
 * @updatetime 2024.5.7
 * @author xiangjun
 */
// ͳ�ƽڵ����
int getListCount(MENU_T *head) {
    int count = 0;
    MENU_T *current = head;
    while (current != NULL) {
        count++;
        current = current->next;
    }
    return count;
}
///**
// * �������ƻ�ȡ��Ʒ��Ϣ
// * @param head   ͷ�ڵ�
// * @param name  ��Ʒ����
// * @return
// */
//// �������ƻ�ȡ��Ʒ��Ϣ
//MENU_T* getMenuInfoByName(MENU_T *head, char *name) {
//    MENU_T *current = head;
//    while (current != NULL) {
//        if (strcmp(current->name, name) == 0) {
//            return current;
//        }
//        current = current->next;
//    }
//    return NULL;
//}
//
//// ����ID��ȡ��Ʒ��Ϣ
MENU_T* getMenuInfoById(MENU_T *head, int id) {
    MENU_T *current = head;
    while (current != NULL) {
        if (current->id == id) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

//// ����λ�û�ȡ��Ʒ��Ϣ
//MENU_T* getMenuInfoByPos(MENU_T *head, int pos) {
//    MENU_T *current = head;
//    int count = 0;
//    while (current != NULL) {
//        if (count == pos) {
//            return current;
//        }
//        count++;
//        current = current->next;
//    }
//    return NULL;
//}
/**
 * ɾ����Ʒ
 * @param head ͷ�ڵ�
 * @param name ��Ʒ����
 * @updatetime 2024.5.7
 * @author xiangjun
 */
// ɾ����Ʒ
void deleteMenu(MENU_T **head, char *name) {
    MENU_T *current = *head;
    MENU_T *prev = NULL;

    while (current != NULL) {
        if (strcmp(current->name, name) == 0) {
            if (prev == NULL) {
                *head = current->next;
            } else {
                prev->next = current->next;
            }
            free(current);
            return;
        }
        prev = current;
        current = current->next;
    }
}

// ��ӡ��Ʒ����
// ��ӡ��Ʒ����
void printMenuList(MENU_T *head) {
    MENU_T *current = head;

    while (current != NULL) {
        printf("%d\t%s\t%.2lf\t%s\n", current->id, current->name, current->price, current->info);
        current = current->next;
    }
}


// �޸Ĳ�Ʒ��Ϣ
void modifyMenu(MENU_T *menu, int id, char *name, float price, char *info) {
    menu->id = id;
    strcpy(menu->name, name);
    menu->price = price;
    strcpy(menu->info, info);
}