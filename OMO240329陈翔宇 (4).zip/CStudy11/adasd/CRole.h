#ifndef _CROLE_H_
#define _CROLE_H_
void usermanageWin();

#endif