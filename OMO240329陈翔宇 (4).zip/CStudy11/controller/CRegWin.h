//
// Created by 1 on 2024/4/23.
//

#ifndef _CREGWIN_H
#define _CREGWIN_H
extern void regWin();

#endif //CSTUDY09_CREGWIN_H
