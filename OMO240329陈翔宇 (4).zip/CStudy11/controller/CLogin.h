#ifndef _CLOGIN_H_
#define _CLOGIN_H_
extern void loginWin();
int authenticate(char *username, char *password);

#endif