
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>
#define MAX_ACCOUNTS 10
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50

/**
 * �����˺�����
 */
char accounts[MAX_ACCOUNTS][2][MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH];
int check(){
    strcpy(accounts[0][0], "user1");
    strcpy(accounts[0][1], "password1");
    strcpy(accounts[1][0], "user2");
    strcpy(accounts[1][1], "password2");
}
/**
 * �˺�������
 * @param username
 * @param password
 * @return
 */
void login(char *username, char *password) {
    if(strcmp(username, "") == 0 || strcmp(password, "") == 0) {
        printf("�˺Ż�����Ϊ�գ�����������\n");
    } else {
        for (int i = 0; i < MAX_ACCOUNTS; i++) {
            if(strcmp(username, accounts[i][0]) == 0 && strcmp(password, accounts[i][1]) == 0) {
                printf("��¼�ɹ���\n");
            }
        }
        printf("�˺������������������\n");
    }
}
/**
 * ��Ļչʾ�͹���ƶ�
 *
 */
void screen()
{
    printf("******************************************\n");
    printf("*             ��¼ϵͳ                     *\n");
    printf("*                                         *\n");
    printf("*                                         *\n");
    printf("*                                         *\n");
    printf("* �˺�:                                    *\n");
    printf("*                                         *\n");
    printf("*                                         *\n");
    printf("* ����:                                   *\n");
    printf("******************************************\n");

    COORD pos;
    pos.X = 8;
    pos.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
/**
 * �������
 * @return
 */
int main()
{
    check();
    screen();

    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int username_index = 0;
    int password_index = 0;
    char ch;

    while ((ch = getch()) != '\r') {
        if (ch == 8) { // �˸��
            if (username_index > 0) {
                username_index--;
                printf("\b \b");
            }
        } else {
            if (username_index < MAX_USERNAME_LENGTH - 1) {
                username[username_index++] = ch;
                putch(ch);
            }
        }
    }
    username[username_index] = '\0';

    printf("\n");
    COORD pos;
    pos.X = 9;
    pos.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);

    while ((ch = getch()) != '\r') {
        if (ch == 8) {
            if (password_index > 0) {
                password_index--;
                printf("\b \b");
            }
        } else {
            if (password_index < MAX_PASSWORD_LENGTH - 1) {
                password[password_index++] = ch;
                putch('*');
            }
        }
    }
    password[password_index] = '\0';
    printf("\n");
    login(username,password);


    return 0;

}