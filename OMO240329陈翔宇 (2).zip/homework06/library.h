#ifndef HOMEWORK06_LIBRARY_H
#define HOMEWORK06_LIBRARY_H

void hello(void);

#endif //HOMEWORK06_LIBRARY_H
